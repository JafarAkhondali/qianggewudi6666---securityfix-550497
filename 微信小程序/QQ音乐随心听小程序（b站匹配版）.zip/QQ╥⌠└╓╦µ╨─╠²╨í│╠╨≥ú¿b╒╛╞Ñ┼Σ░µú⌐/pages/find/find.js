// pages/find/find.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
     imgdata:[
       {
       "pic":"https://p1.music.126.net/0L5drAV43FLJk6J9dRhfew==/109951165911947840.jpg",
       "name":"林俊杰"
     },
     {
       "pic":"http://p1.music.126.net/1tSJODTpcbZvNTCdsn4RYA==/109951165034950656.jpg",
       "name":"薛之谦"
     },
     {
       "pic":"	https://p1.music.126.net/rYYhHXZHwCfizE0N46F37Q==/109951166115911716.jpg?param=130y130",
       "name":"陈奕迅"
     },
     {
      "pic":"	https://p1.music.126.net/oDmmsqtO5T3OxEQHc71kKA==/109951166501988717.jpg?param=130y130",
      "name":"烟(许佳豪)的音乐"
    },
    {
      "pic":"	https://p1.music.126.net/Ieq9StJjPVyRPlmeOanldQ==/109951166470091750.jpg?param=130y130",
      "name":"队长"
    },
    {
      "pic":"	http://p1.music.126.net/Hf-0kjdtbn1169gN7WE_hA==/109951163720138703.jpg?param=130y130",
      "name":"五月天"
    }
    ],
    "musicdata":[
       {
         "pic":"https://p1.music.126.net/XB-dSVy5sF9l6M-sbRSJqg==/109951165545379257.jpg?param=140y140",
         "name":"[流行点唱机] 2010年代华语热播 每日30首"
       },
       {
        "pic":"https://p2.music.126.net/c3224ylHr91oZQ1DmHdL2g==/109951166659558933.jpg?param=140y140",
        "name":"[华语速爆新歌] 张艺兴真情流露，谱写关于双向奔赴的默契暗号"
      },
      {
        "pic":"https://p2.music.126.net/QmymmJ90U7DymQjh3CzwMA==/109951166656700807.jpg?param=140y140",
        "name":"[一周影视热歌] 张紫宁轻轻吟唱 浓墨重彩 落笔成殇"
      },

      {
        "pic":"https://p2.music.126.net/0VRN6GBaPibXxfKz2UbzdA==/109951165959686617.jpg?param=140y140",
        "name":"[华语私人订制] 最懂你的华语推荐 每日更新35首"
      },

      {
        "pic":"	https://p2.music.126.net/PnK8JhpqPWkKxmHLi-PXaQ==/109951165724236619.jpg?param=140y140",
        "name":"夏日入侵企画/棱镜/落日飞车/新裤子/告五人"
      },

      {
        "pic":"	https://p2.music.126.net/vETe1sccMem-G0giK9NHsQ==/109951166644073429.jpg?param=140y140",
        "name":"下架说唱:下架说唱"
      },


    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})